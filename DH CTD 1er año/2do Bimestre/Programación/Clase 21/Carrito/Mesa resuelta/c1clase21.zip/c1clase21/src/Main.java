public class Main {
    public static void main(String[] args) {


        Tamagochi tamagochi = new Tamagochi();
        tamagochi.darBebida();
        tamagochi.darMimos();
        tamagochi.darMimos();
        tamagochi.darMimos();
        tamagochi.darComida();
        tamagochi.darComida();
        tamagochi.darBebida();

    }
}