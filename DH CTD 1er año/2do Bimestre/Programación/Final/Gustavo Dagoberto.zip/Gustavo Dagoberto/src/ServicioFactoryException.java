public class ServicioFactoryException extends Exception{
    public ServicioFactoryException(String message) {
        super(message);
    }
}
